# InnovationWeek
Aplicación para evaluar proyectos de la semana e innovación de la UTEQ Querétaro.
